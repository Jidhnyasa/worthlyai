import{f as w}from"./api-C92ikH36.js";const g="*{box-sizing:border-box;margin:0;padding:0}#worthly-badge{display:flex;align-items:center;gap:8px;padding:12px 18px;background:#fff;border:.5px solid #e7e5e4;border-radius:9999px;box-shadow:0 4px 16px #0000001f,0 1px 4px #00000014;cursor:pointer;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,system-ui,sans-serif;font-size:14px;font-weight:500;color:#1c1917;transition:transform .15s ease,box-shadow .15s ease;white-space:nowrap;outline:none;-webkit-font-smoothing:antialiased}#worthly-badge:hover{transform:scale(1.03);box-shadow:0 6px 20px #00000029,0 2px 6px #0000001a}#worthly-badge:active{transform:scale(.98)}#worthly-badge:focus-visible{outline:2px solid hsl(32,95%,54%);outline-offset:2px}#worthly-badge svg{flex-shrink:0}",u=30*60*1e3,l=new Map;function m(e){const t=l.get(e);return t?Date.now()>t.expiresAt?(l.delete(e),null):t.data:null}function y(e,t){l.set(e,{data:t,expiresAt:Date.now()+u})}const b={wait:{bg:"hsl(40 90% 92%)",color:"hsl(40 60% 30%)"},buy:{bg:"hsl(140 50% 90%)",color:"hsl(140 60% 25%)"},skip:{bg:"hsl(0 70% 92%)",color:"hsl(0 60% 35%)"}},v=`
@keyframes wp-fadein {
  from { opacity: 0; transform: translateY(8px); }
  to   { opacity: 1; transform: translateY(0); }
}
@keyframes wp-spin {
  to { transform: rotate(360deg); }
}

#worthly-panel {
  position: fixed;
  bottom: 80px;
  right: 24px;
  width: 360px;
  max-height: 70vh;
  overflow-y: auto;
  background: #ffffff;
  border: 0.5px solid #e7e5e4;
  border-radius: 12px;
  box-shadow: 0 4px 24px rgba(0,0,0,0.12);
  padding: 20px;
  z-index: 999998;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
  -webkit-font-smoothing: antialiased;
  animation: wp-fadein 0.15s ease forwards;
}

.wp-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 14px;
}
.wp-brand {
  display: flex;
  align-items: center;
  gap: 6px;
}
.wp-brand-text {
  font-size: 14px;
  font-weight: 500;
  color: #1c1917;
}
.wp-close {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 32px;
  height: 32px;
  border: none;
  background: none;
  border-radius: 6px;
  cursor: pointer;
  color: #a8a29e;
  transition: background 0.1s, color 0.1s;
  flex-shrink: 0;
}
.wp-close:hover { background: #f5f5f4; color: #57534e; }

.wp-verdict-row { margin-bottom: 10px; }
.wp-verdict-pill {
  display: inline-block;
  font-size: 16px;
  font-weight: 500;
  padding: 6px 14px;
  border-radius: 999px;
  letter-spacing: 0.02em;
}
.wp-headline {
  font-size: 15px;
  font-weight: 500;
  color: #1c1917;
  line-height: 1.45;
  margin-bottom: 14px;
}
.wp-reasons-label {
  font-size: 11px;
  color: #a8a29e;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  margin-bottom: 10px;
}
.wp-reasons { display: flex; flex-direction: column; gap: 12px; margin-bottom: 16px; }
.wp-reason  { display: flex; align-items: flex-start; gap: 10px; }
.wp-reason-dot {
  flex-shrink: 0;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: hsl(32,95%,54%);
  margin-top: 4px;
}
.wp-reason-body { display: flex; flex-direction: column; gap: 2px; }
.wp-reason-label { font-size: 13px; font-weight: 500; color: #1c1917; }
.wp-reason-detail { font-size: 13px; color: #78716c; line-height: 1.5; margin: 0; }

.wp-scores {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 6px;
}
.wp-score {
  display: flex;
  flex-direction: column;
  align-items: center;
  background: #fafaf9;
  border-radius: 8px;
  padding: 8px 4px;
  gap: 2px;
}
.wp-score-label { font-size: 10px; color: #a8a29e; text-transform: uppercase; letter-spacing: 0.04em; }
.wp-score-value { font-size: 18px; font-weight: 500; color: #1c1917; }

.wp-loading {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 12px;
  padding: 4px 0 8px;
}
.wp-spinner {
  width: 20px;
  height: 20px;
  border: 2.5px solid #e7e5e4;
  border-top-color: hsl(32,95%,54%);
  border-radius: 50%;
  animation: wp-spin 0.7s linear infinite;
}
.wp-loading-text {
  font-size: 13px;
  color: #78716c;
  line-height: 1.5;
}
.wp-error {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 12px;
  padding: 4px 0 8px;
}
.wp-error-text {
  font-size: 13px;
  color: #78716c;
  line-height: 1.5;
}
.wp-retry {
  font-size: 13px;
  font-weight: 500;
  color: #1c1917;
  background: #f5f5f4;
  border: 0.5px solid #e7e5e4;
  border-radius: 6px;
  padding: 6px 14px;
  cursor: pointer;
  transition: background 0.1s;
}
.wp-retry:hover { background: #e7e5e4; }
`,k='<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" aria-hidden="true"><circle cx="8" cy="8" r="8" fill="hsl(32,95%,54%)"/><text x="8" y="12" text-anchor="middle" font-size="9" font-weight="800" font-family="system-ui,sans-serif" fill="white">W</text></svg>',C='<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>';function E(){const e=document.createElement("div");return e.id="worthly-panel",e.setAttribute("role","dialog"),e.setAttribute("aria-label","Worthly verdict"),e.innerHTML=`
    <div class="wp-header">
      <div class="wp-brand">${k}<span class="wp-brand-text">Worthly verdict</span></div>
      <button class="wp-close" id="worthly-panel-close" aria-label="Close">${C}</button>
    </div>
    <div id="worthly-panel-body"></div>`,e}function z(e){e.innerHTML=`
    <div class="wp-loading">
      <div class="wp-spinner"></div>
      <p class="wp-loading-text">Reading the page and generating a verdict — usually 5–15 seconds.</p>
    </div>`}function f(e,t){const s=b[t.verdict],o=t.reasons.map(r=>`
    <div class="wp-reason">
      <span class="wp-reason-dot"></span>
      <div class="wp-reason-body">
        <span class="wp-reason-label">${r.label}</span>
        <p class="wp-reason-detail">${r.detail}</p>
      </div>
    </div>`).join(""),n=Object.entries(t.scores).map(([r,a])=>`
    <div class="wp-score">
      <span class="wp-score-label">${r}</span>
      <span class="wp-score-value">${a}</span>
    </div>`).join("");e.innerHTML=`
    <div class="wp-verdict-row">
      <span class="wp-verdict-pill" style="background:${s.bg};color:${s.color}">${t.verdict.toUpperCase()}</span>
    </div>
    <p class="wp-headline">${t.headline}</p>
    <p class="wp-reasons-label">Why this verdict</p>
    <div class="wp-reasons">${o}</div>
    <div class="wp-scores">${n}</div>`}function L(e,t){e.innerHTML=`
    <div class="wp-error">
      <p class="wp-error-text">Couldn't generate a verdict right now. Try again in a moment.</p>
      <button class="wp-retry" id="worthly-retry">Retry</button>
    </div>`,e.querySelector("#worthly-retry").addEventListener("click",t)}function S(e,t,s){if(s.querySelector("#worthly-panel"))return;if(!s.querySelector("#worthly-panel-style")){const i=document.createElement("style");i.id="worthly-panel-style",i.textContent=v,s.appendChild(i)}const o=E();s.appendChild(o);const n=o.querySelector("#worthly-panel-body");let r=!1;function a(){r||(r=!0,o.style.transition="opacity 0.15s ease, transform 0.15s ease",o.style.opacity="0",o.style.transform="translateY(8px)",setTimeout(()=>o.remove(),150),document.removeEventListener("click",p,!0),document.removeEventListener("keydown",d))}function p(i){const x=document.getElementById("worthly-host");x&&!x.contains(i.target)&&a()}function d(i){i.key==="Escape"&&a()}o.querySelector("#worthly-panel-close").addEventListener("click",a),setTimeout(()=>{document.addEventListener("click",p,!0),document.addEventListener("keydown",d)},0);function c(){z(n),w(t).then(i=>{y(e,i),f(n,i)}).catch(()=>{L(n,c)})}const h=m(e);h?f(n,h):c()}const T=/\/dp\/([A-Z0-9]{10})/;function $(){var e;return((e=location.pathname.match(T))==null?void 0:e[1])??null}function B(e){if(document.getElementById("worthly-host"))return;const t=document.createElement("div");t.id="worthly-host",Object.assign(t.style,{position:"fixed",bottom:"24px",right:"24px",zIndex:"999999",width:"auto",height:"auto",margin:"0",padding:"0",border:"none",background:"none"}),document.body.appendChild(t);const s=t.attachShadow({mode:"open"}),o=document.createElement("style");o.textContent=g,s.appendChild(o);const n=document.createElement("button");n.id="worthly-badge",n.setAttribute("aria-label","Get Worthly verdict for this product"),n.innerHTML='<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" aria-hidden="true"><circle cx="9" cy="9" r="9" fill="hsl(32,95%,54%)"/><text x="9" y="13.5" text-anchor="middle" font-size="10" font-weight="800" font-family="system-ui,sans-serif" fill="white">W</text></svg><span>Worthly</span>',n.addEventListener("click",()=>{console.log("[Worthly] badge clicked, ASIN:",e),S(e,location.href,s)}),s.appendChild(n)}if(window===window.top){const e=$();e&&B(e)}
